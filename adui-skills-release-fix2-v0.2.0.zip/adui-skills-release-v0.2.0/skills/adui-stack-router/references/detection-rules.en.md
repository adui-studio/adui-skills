# Detection Rules - English fallback

Use explicit dependencies, framework manifests, config imports, and database providers as high-confidence evidence. Characteristic source files and APIs are medium confidence. Weak directory-name heuristics must not activate a Profile by themselves.

Keep Tailwind and UnoCSS independent, distinguish Vite+ from normal Vite, prefer Prisma datasource providers for database engines, distinguish uni-app from uni-app x, and add WeChat CloudBase only when CloudBase usage is present.


When both NestJS and Prisma have strong evidence, select the combined `nestjs-prisma` profile; do not attach Prisma integration rules to NestJS-only projects.


3D/GPU profiles inherit the shared `3d` profile. If multiple high-level engines such as Three.js, Babylon.js, and CesiumJS are detected, emit an architecture warning and require explicit coordinate, camera, context, and resource-ownership decisions.
