# Contributing

[简体中文](./CONTRIBUTING.md) | [English](./CONTRIBUTING.en.md)

GitHub is the only primary repository; CNB is a synchronized mirror. Chinese is the default documentation language and matching `.en.md` files are the English fallback.

Before submitting changes, run:

```bash
npm run validate
npm test
```

Changes to the Profile Installer should keep npm, pnpm, Yarn, Bun, lockfile-conflict, workspace-root, and Windows `.cmd` runner tests green.

Use `npm run updates:check` for Registry changes and `npm run detect:stack -- <project-root>` for router changes. Third-party upstream updates must be reviewed manually and never auto-merged.

## Local skill references

`localSkills` may reference only ADui skills that already exist and pass validation. Planned skills are added to profiles only after implementation and validation.


## Release-related changes

Run `npm run release:check -- --tag vX.Y.Z` for release work. Tags are created manually from merged `main` commits, and `v0.2.x` publishing requires a real Folder Hash lock baseline. See [Release Process](./docs/releasing.en.md).
